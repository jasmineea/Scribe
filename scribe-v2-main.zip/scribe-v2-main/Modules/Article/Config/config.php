<?php

return [
    'name' => 'Article',
];
