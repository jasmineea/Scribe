<?php

return [
    'name' => 'Customer'
];
