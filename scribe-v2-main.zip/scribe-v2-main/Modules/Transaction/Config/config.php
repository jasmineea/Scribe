<?php

return [
    'name' => 'Transaction'
];
