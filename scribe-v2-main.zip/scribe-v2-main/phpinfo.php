<?php
echo phpinfo();
