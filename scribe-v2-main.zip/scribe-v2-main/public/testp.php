<?php
exec("echo Hello World", $output);
var_dump($output);
?>
